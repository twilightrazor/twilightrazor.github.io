1.Format a 3 1/2 inch diskette��� :Label it Lemmings��� (in this case my
floppy drive is A:\)
2.Click on the zipped lemmings file and start winzip
3.Click on the Winzip Classic button in� the bottom right corner.
4.Click on 'select all' in the Actions menu (TOP)�� All files become blue
5.Press the extract button
6.In the upper left corner� Type:���� A:\����� (if your floppy drive is A:\
of course)
7.Press the 'extract' button on the right
8.Winzip will now extract the lemmings files to floppy

Now install lemmings from the floppy disk
If it doesn't work try it in DOS

Have fun

Someone