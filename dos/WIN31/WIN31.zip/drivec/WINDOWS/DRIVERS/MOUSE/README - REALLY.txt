You MUST go to the Win31DOSBox/DOSBox folder and make sure that the [cpu] section includes this line:

integration device = true
